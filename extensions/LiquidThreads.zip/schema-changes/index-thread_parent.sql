CREATE INDEX thread_parent ON /*$wgDBprefix*/thread(thread_parent);
