-- Add thread_signature field
ALTER TABLE /*_*/thread ADD COLUMN thread_signature TINYBLOB NULL;
